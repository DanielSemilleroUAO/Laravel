<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UsersController extends Controller
{
	public function create(){
		return view('admin.users.create');
	}
    //
    public function store(Request $request){
    	//dd($request->all());
    	$user = new User($request->all());	
    	//dd($user);
    	$user->save();
    	dd('Usuario creado');
    }
}
