<!DOCTYPE html>
<html>
<head>
	<title> <?php echo $__env->yieldContent('title', 'Default'); ?> | Panel de administración</title>
	<link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.css')); ?>">
</head>
<body>
	<?php echo $__env->make('admin.template.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<section>	
		<?php echo $__env->yieldContent('content'); ?>
	</section>
	<!--Colocar siempre primero la Jquery -->
	<script src="<?php echo e(asset('plugins/jquery/js/jquery-3.4.1.js')); ?>"></script>
	<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.js')); ?>"></script>
</body>
</html><?php /**PATH /home/daniel/project-laravel/blog/resources/views/admin/template/main.blade.php ENDPATH**/ ?>