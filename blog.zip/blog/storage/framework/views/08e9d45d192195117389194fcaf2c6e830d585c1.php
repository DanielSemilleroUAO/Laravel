
<?php 
	//echo dd($prueba->title);
?>

<!DOCTYPE html>
<html>
<head>
	<title> <?php echo e($prueba->title); ?> </title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/general.css')); ?>">
</head>
<body>
	<?php echo e($prueba->title); ?>


	<?php for($i = 0; $i< 5; $i++): ?>
		<?php echo e($i); ?>

	<?php endfor; ?>

	<br><br>
	<h1><?php echo e($prueba->title); ?></h1>
	<hr>
	<?php echo e($prueba->content); ?>

	<hr>
	<?php echo e($prueba->user->name); ?> | <?php echo e($prueba->category->name); ?>|
	<?php $__currentLoopData = $prueba->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($tag->name); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>>

<?php /**PATH /home/daniel/project-laravel/blog/resources/views/test/index.blade.php ENDPATH**/ ?>