<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <h1> Hi </h1>
    <a href="" class="btn btn-success"> Botón </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/project-laravel/blog/resources/views/welcome.blade.php ENDPATH**/ ?>