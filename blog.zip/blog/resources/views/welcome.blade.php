@extends('admin.template.main')

@section('title', 'Inicio')

@section('content')
    <h1> Hi </h1>
    <a href="" class="btn btn-success"> Botón </a>
@endsection