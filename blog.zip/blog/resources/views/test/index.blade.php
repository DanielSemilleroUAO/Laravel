
<?php 
	//echo dd($prueba->title);
?>

<!DOCTYPE html>
<html>
<head>
	<title> {{ $prueba->title}} </title>
	<link rel="stylesheet" type="text/css" href="{{ asset('css/general.css') }}">
</head>
<body>
	{{ $prueba->title }}

	@for($i = 0; $i< 5; $i++)
		{{$i}}
	@endfor

	<br><br>
	<h1>{{ $prueba->title}}</h1>
	<hr>
	{{ $prueba->content}}
	<hr>
	{{ $prueba->user->name}} | {{$prueba->category->name}}|
	@foreach($prueba->tags as $tag)
		{{$tag->name}}
	@endforeach

</body>
</html>>

